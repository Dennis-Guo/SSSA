# Spatial-Query-by-Sketch
