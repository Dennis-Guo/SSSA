#!/bin/bash

singularity exec --nv ~/zhangshu/dl.simg python App.py
